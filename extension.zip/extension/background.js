chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type !== 'ANALYZE') return;

  (async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      // Inject content script in case it wasn't auto-injected (e.g. extension reload)
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js'],
      }).catch(() => {});

      // Extract page text via content script
      const [{ result: text }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => document.body.innerText.slice(0, 50000),
      });

      if (!text || text.trim().length < 100) {
        sendResponse({ error: 'Not enough text found on this page. Make sure the contract is visible.' });
        return;
      }

      const res = await fetch('http://localhost:8000/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, freelancer_mode: msg.freelancer_mode || false }),
      });

      if (!res.ok) {
        const body = await res.text();
        sendResponse({ error: `Backend error (${res.status}): ${body}` });
        return;
      }

      const analysis = await res.json();

      // Send highlights to the page
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js'],
      }).catch(() => {});

      chrome.tabs.sendMessage(tab.id, {
        type: 'HIGHLIGHT_CLAUSES',
        clauses: analysis.clauses || [],
      });

      sendResponse({ ok: true, analysis });
    } catch (err) {
      const msg =
        err.message.includes('fetch')
          ? 'Cannot reach backend. Is it running on port 8000?'
          : err.message;
      sendResponse({ error: msg });
    }
  })();

  return true; // keep channel open for async response
});
